/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package charlie.server;

/**
 *
 * @author timhoangt
 */

import charlie.card.Shoe;
import java.util.Random;


/**
 * This class implements a test scenario.
 * @author Ron Coleman
 */


public class MyShoe01 extends Shoe { 
    
    public MyShoe01() {
        super.numDecks = 1;
    }
    
}