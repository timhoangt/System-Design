package charlie.server.bot;

/**
 *
 * @author timhoangt
 * Dewey extends Huey making it essentially a duplicate of the Huey bot.
 */
public class Dewey extends Huey {
    
}
