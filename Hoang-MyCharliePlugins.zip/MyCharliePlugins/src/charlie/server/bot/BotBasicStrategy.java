package charlie.server.bot;

import charlie.client.BasicStrategy;

/**
 *
 * @author timhoangt
 * Bot basic strategy extends basic strategy making it
 * essentially a duplicate of basic strategy.
 */
class BotBasicStrategy extends BasicStrategy {
    
}
